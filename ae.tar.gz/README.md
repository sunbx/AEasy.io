# AEasy.io

> AEasy is Convenient Aeternity Framework . AEasy quickly, conveniently realize Aeternity aaepp development

![](https://github.com/sunbx/AEasy.io/blob/master/aeasy.jpeg?raw=true)

|Author|position|
|:----    |:---  
|283122529@qq.com|development|
|81510329@qq.com |design|

|url|doc|
 |:---   |:---   |
|http://aeasy.io  | https://app.gitbook.com/@283122529/s/aeasy/ |


> AEasy is Convenient Aeternity Framework . AEasy quickly, conveniently realize Aeternity aepp development


**AEASY**   is based on rapid Aeternity block chain (non-profit), to help developers implement aepp development work, developers do not need to close the block chain chain principle and implementation way, don't even need the concept of block chain, can quickly stop the submitted data link, you can use AEASY is simple and convenient way of API calls to help you to complete the development work. Then quickly start your aepp development journey. Let's help it out, let's make Aeternity better,Each transaction in AEASY can be directly inquired through the node on the chain, following the principle of openness and transparency of the block chain

####     **AEASY** does the following
- You can call common apis for nodes
- You can But the implementation of data on the chain
- You can quickly use mnemonics to get the private key, and quickly generate mnemonics
- You can call middleware apis, such as transfer domain name list, etc
- You can Create AEX9 TOKENS with one key
- Deployment and use of predictive chicken (in development)



# Quick start

##### Hello Aeternal brothers, let's step by step into the AEASY journey

##### 1. Visit AEASY's official website aeasy.io

![](https://www.showdoc.cc/server/api/common/visitfile/sign/2607f2f8073d168e02c680e58b7b3ba9?showdoc=.jpg)

##### 2. Click login or start quickly to go to the login page

![](https://www.showdoc.cc/server/api/common/visitfile/sign/20e1f67ba9e812a8838892fe9934091d?showdoc=.jpg)

##### 3. If you do not have an account, please use the email account to register. After successful registration, you will enter the user center page

![](https://www.showdoc.cc/server/api/common/visitfile/sign/ccebe40f796ac8f0b5f4f210ff22fada?showdoc=.jpg)



#####Your address on this page you can see a qr code and address string and appId and appSecret, but is invisible to the appId and appSecret, because the new user need to change the address to your account to make more than 1 ae , can obtain appId and appSecret is stolen brush. In order to prevent hackers appId and appSecret is very important, please careful custody, appId and appSecret later introduction to use





# Based Introduce

### What can the basic API do ?

The basic API can provide some basic queries of the node, and quickly implement the data chain operation, the chain operation will deduct the account ae as a handling fee, almost no money, if you have the demand for data chain and is free to the user can use this interface is the best choice

- Gets the current block height interface,This interface can be used to obtain the latest block height of ae
- Obtain the specific contents of the specific information on the chain, including address information, and the data on the chain, transfer amount, etc., can use the interface to obtain the data on the chain.
- Gets the balance of the account under the corresponding address
- Get the wallet list top 500
- Obtain some basic data such as ae price and quantity
- The data is passed into the block link port, and the data below 50000 length can be stored into the block chain. The block chain data can be saved permanently, which only needs to pay 0.0001ae of fuel fee, which is equivalent to no cost 😆😆😆

If you want to make money , check out the advanced API, which will meet your needs



# Advanced Introduce
### What can advanced apis do?
Advanced API can provide some middleware data and aens domain name data, so that aepp can quickly access the transfer records, etc., can quickly register aens, transfer, update

- Login by mnemonic
- Register by mnemonic
- Transfers between wallets
- A record of transfers between wallets
- Get the account balance
- Acquire aens in auction - near the end of the auction
- Get aens auction - the most expensive domain name
- Gets the domain name that aens is about to expire
- Get aens my-registered domain name
- Get aens my - about to expire domain name
- Update the domain name
- Domain name details
- Domain name registration
- The domain name transfer

Information about AEX9 API operations will be added later







